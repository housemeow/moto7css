<?php
$images_path="images/";
$upload_path="../upload/"
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>{{Rename me}}</title>
		<!--css-->
		<link href="http://yui.yahooapis.com/3.18.1/build/cssreset/cssreset-min.css" rel="stylesheet">
		<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
		<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
		<link href="js_fk/bxslider/jquery.bxslider.css" rel="stylesheet">
		<link rel="stylesheet/less" type="text/css" href="css/component-brands.less" />
		<!--js-->
		<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/1.7.5/less.min.js"></script>
		<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
		<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
		<script src="https://rawgit.com/leafo/sticky-kit/v1.0.4/jquery.sticky-kit.min.js"></script>
		<script src="js_fk/bxslider/jquery.bxslider.min.js"></script>
		<script src="js/function.js"></script>
	</head>
	<body>
		<div class="brands">
			<div class="header-logo">
				<a href="#"></a>
			</div>
			<ul>
				<li class="active">
					<a href="#"><div><img src="<?php echo $upload_path ?>brands1.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands2.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands3.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands4.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands5.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands6.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands7.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands8.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
				<li>
					<a href="#"><div><img src="<?php echo $upload_path ?>brands9.png" alt="brands"></div>
					<span>該廠牌最新文章A<br>該廠牌最新文章B</span></a>
				</li>
			</ul>
		</div>
	</body>
</html>